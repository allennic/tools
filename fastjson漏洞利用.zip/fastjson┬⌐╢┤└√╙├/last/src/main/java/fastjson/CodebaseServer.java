package fastjson;

import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;

public class CodebaseServer {
    /***
     * 启动http服务器，提供下载远程要调用的类
     *
     * @throws IOException
     */
    public static void lanuchCodebaseURLServer(String ip, int port) throws IOException {
        System.out.println("Starting HTTP server");
        HttpServer httpServer = HttpServer.create(new InetSocketAddress(ip, port), 0);
        httpServer.createContext("/", new HttpFileHandler());
        httpServer.setExecutor(null);
        httpServer.start();
    }
}
